// Diagnostic-only instrumentation; no application files changed.
const dns=require('node:dns'),http=require('node:http'),fs=require('node:fs');
const lookup=dns.lookup;
dns.lookup=function(host,options,callback){
 if(host!=='backend')return lookup.apply(this,arguments);
 if(typeof options==='function'){callback=options;options={};}
 process.nextTick(()=>options?.all?callback(null,[{address:'127.0.0.1',family:4}]):callback(null,'127.0.0.1',4));
};
const emit=http.Server.prototype.emit;
http.Server.prototype.emit=function(event,request,response,...rest){
 if(event==='request'){
  const started=performance.now(),id=request.headers['x-diagnostic-id'];
  if(id)response.on('finish',()=>fs.appendFileSync(process.env.DOCLENS_DIAGNOSTIC_ACCESS_LOG,JSON.stringify({at:new Date().toISOString(),id,method:request.method,path:request.url,status:response.statusCode,contentType:response.getHeader('content-type')||null,location:response.getHeader('location')||null,elapsedMs:performance.now()-started})+'\n'));
 }
 return emit.call(this,event,request,response,...rest);
};
