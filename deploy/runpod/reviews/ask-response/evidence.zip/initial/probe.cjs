const fs=require('node:fs'),path=require('node:path'),net=require('node:net'),http=require('node:http'),crypto=require('node:crypto');
const {spawn}=require('node:child_process'),{createRequire}=require('node:module');
const root='/workspace/DocLens',out=__dirname,req=createRequire(path.join(root,'frontend/package.json'));
let frontend,backend;
(async()=>{
 const secret=crypto.randomBytes(32).toString('hex'),{SignJWT}=await import(req.resolve('jose'));
 const token=seconds=>new SignJWT({role:'admin'}).setProtectedHeader({alg:'HS256'}).setIssuer('doclens').setAudience('doclens-frontend').setIssuedAt().setExpirationTime(Math.floor(Date.now()/1000)+seconds).sign(new TextEncoder().encode(secret));
 let mode='json',currentID='';
 backend=http.createServer(async(r,s)=>{
  let body='';for await(const chunk of r){body+=chunk;if(body.length>4096){s.writeHead(413);s.end();return;}}
  const id=body?JSON.parse(body).question.replace('diagnostic:',''):currentID;
  const start=performance.now();
  s.on('finish',()=>fs.appendFileSync(path.join(out,'backend-fixture.jsonl'),JSON.stringify({at:new Date().toISOString(),id,method:r.method,path:r.url,mode,status:s.statusCode,contentType:s.getHeader('content-type')||null,location:s.getHeader('location')||null,elapsedMs:performance.now()-start})+'\n'));
  if(r.url.startsWith('/login')){s.writeHead(200,{'Content-Type':'text/html'});s.end('<html><body>Synthetic upstream login page</body></html>');}
  else if(mode==='html'){s.writeHead(500,{'Content-Type':'text/html'});s.end('<html><body>Synthetic backend failure</body></html>');}
  else if(mode==='redirect'){s.writeHead(302,{'Location':'/login'});s.end();}
  else{s.writeHead(200,{'Content-Type':'application/json'});s.end(JSON.stringify({answer:'Synthetic diagnostic answer',citations:[]}));}
 });
 await new Promise((resolve,reject)=>{backend.once('error',reject);backend.listen(8000,'127.0.0.1',resolve);});
 const socket=net.createServer();await new Promise(r=>socket.listen(0,'127.0.0.1',r));const port=socket.address().port;await new Promise(r=>socket.close(r));
 const log=fs.openSync(path.join(out,'frontend.log'),'w');
 frontend=spawn('node',['--require',path.join(out,'preload.cjs'),'node_modules/next/dist/bin/next','start','--hostname','127.0.0.1','--port',String(port)],{cwd:path.join(root,'frontend'),env:{...process.env,DOCLENS_SESSION_SECRET:secret,DOCLENS_DIAGNOSTIC_ACCESS_LOG:path.join(out,'frontend-access.jsonl'),NEXT_TELEMETRY_DISABLED:'1'},stdio:['ignore',log,log]});
 const base='http://127.0.0.1:'+port;
 const {expect}=req('@playwright/test');await expect.poll(async()=>{if(frontend.exitCode!==null)throw Error('Next exited');try{return(await fetch(base)).status}catch{return 0}},{timeout:20000}).toBe(200);
 const valid=await token(3600),expired=await token(-60),results=[];
 for(const c of [
  {name:'anonymous',path:'/api/ask'},
  {name:'expired-session',path:'/api/ask',cookie:expired},
  {name:'valid-json',path:'/api/ask',cookie:valid,mode:'json'},
  {name:'backend-html-500',path:'/api/ask',cookie:valid,mode:'html'},
  {name:'backend-redirect-html',path:'/api/ask',cookie:valid,mode:'redirect'},
  {name:'trailing-slash',path:'/api/ask/',cookie:valid,mode:'json'},
  {name:'wrong-frontend-path',path:'/ask',cookie:valid,mode:'json'},
  {name:'wrong-method',path:'/api/ask',method:'GET',cookie:valid,mode:'json'},
 ]){
  currentID='probe-'+crypto.randomUUID();mode=c.mode||'json';let url=base+c.path,method=c.method||'POST',hops=[];
  for(let n=0;n<4;n++){
   const started=performance.now(),headers={'Content-Type':'application/json','X-Diagnostic-ID':currentID};if(c.cookie)headers.Cookie='doclens_session='+c.cookie;
   const r=await fetch(url,{method,headers,body:method==='POST'?JSON.stringify({question:'diagnostic:'+currentID,document_name:'synthetic.pdf'}):undefined,redirect:'manual',signal:AbortSignal.timeout(10000)});
   const ttfb=performance.now()-started,text=await r.text();
   hops.push({at:new Date().toISOString(),method,url,status:r.status,contentType:r.headers.get('content-type'),location:r.headers.get('location'),ttfbMs:ttfb,totalMs:performance.now()-started,bodyBytes:Buffer.byteLength(text),bodyPrefix:text.slice(0,200)});
   if([301,302,303,307,308].includes(r.status)&&r.headers.get('location')){url=new URL(r.headers.get('location'),url).href;if([301,302,303].includes(r.status))method='GET';continue;}
   break;
  }
  results.push({scenario:c.name,id:currentID,sourceScope:'unmodified production Next build; diagnostic DNS/access instrumentation; controlled local upstream, not RunPod',hops});
 }
 const get=name=>results.find(r=>r.scenario===name).hops.at(-1);
 if(get('anonymous').status!==401||!get('anonymous').contentType.includes('json'))throw Error('Unexpected anonymous result');
 if(get('expired-session').status!==401||!get('expired-session').contentType.includes('json'))throw Error('Unexpected expiry result');
 for(const name of ['backend-html-500','backend-redirect-html'])if(get(name).status!==502||!get(name).contentType.includes('json'))throw Error('Upstream HTML unexpectedly forwarded');
 if(get('wrong-frontend-path').status!==404||!get('wrong-frontend-path').contentType.includes('html'))throw Error('Expected wrong-route HTML not reproduced');
 fs.writeFileSync(path.join(out,'results.json'),JSON.stringify(results,null,2)+'\n');
 console.log('PASS diagnostic matrix: 8 cases captured; correct API returns JSON; wrong path reproduces HTML404. Actual reported incident remains unverified.');
})().catch(e=>{console.error(e);process.exitCode=1;}).finally(async()=>{if(frontend)frontend.kill('SIGTERM');if(backend)await new Promise(r=>backend.close(r));});
