"""Focused real Grafana/DocLens browser regression; not final-image acceptance.
Uses existing production dependency images, synthetic credentials, private raw
Grafana network, a read-only dashboard/provisioning fixture and current gateway.
No backend/model/data ingestion needed for this navigation-only regression.
"""
from pathlib import Path
import json,os,subprocess,tempfile,uuid,shutil,time,urllib.request,importlib.util,threading
root=Path(os.environ.get('DOCLENS_REPO','/workspace/DocLens'));out=Path(__file__).parent
name='doclens-back-link-'+uuid.uuid4().hex[:8];frontend=name+'-frontend';grafana=name+'-grafana'
front_image='sha256:60f8893a7727fa08a6457ad4b255b9d47a2da103270484651dd69e70611ac30e'
graf_image='sha256:45900b2eda7da0cbda80b9025e446147d9085fee71675ba86a48a1cad34e4c8a'
def docker(*args,check=True):
 r=subprocess.run(['docker','--host=unix:///var/run/docker.sock',*args],capture_output=True,text=True)
 if check and r.returncode:raise RuntimeError('Docker '+args[0]+' failed: '+r.stderr)
 return r.stdout.strip()
size=sum(json.loads(docker('image','inspect',i))[0]['Size'] for i in [front_image,graf_image])
assert shutil.disk_usage('/workspace').free>2*size+512*1024**2,'Insufficient disk; do not create containers'
servers=[]
try:
 with tempfile.TemporaryDirectory(prefix='doclens-back-link-fixture-',dir='/tmp') as temp:
  fixture=Path(temp);provision=fixture/'provisioning/dashboards';provision.mkdir(parents=True)
  for p in [fixture/'provisioning',provision]:p.chmod(0o755)
  (provision/'doclens.yml').write_text('apiVersion: 1\nproviders:\n  - name: DocLens\n    type: file\n    disableDeletion: true\n    allowUiUpdates: false\n    options:\n      path: /fixture/dashboards\n')
  (provision/'doclens.yml').chmod(0o644)
  runtime=fixture/'runtime';runtime.mkdir(mode=0o755);runtime.chmod(0o755)
  dashboard_dir=runtime/'dashboards';dashboard_dir.mkdir(mode=0o755);dashboard_dir.chmod(0o755)
  template=(root/'deploy/monitoring/dashboards/doclens.json').read_text()
  (dashboard_dir/'doclens.json').write_text(template);(dashboard_dir/'doclens.json').chmod(0o644)
  hashed=subprocess.check_output(['node','-e',"const fs=require('fs');process.stdout.write(require('./node_modules/bcryptjs').hashSync(fs.readFileSync(0,'utf8'),10))"],input=b'Synthetic-$literal-Password-2026',cwd=root/'frontend').decode()
  env=fixture/'frontend.env';env.write_text('DOCLENS_ADMIN_EMAIL=trial@synthetic.invalid\nDOCLENS_ADMIN_PASSWORD_HASH='+hashed+'\nDOCLENS_SESSION_SECRET='+uuid.uuid4().hex+uuid.uuid4().hex+'\nDOCLENS_MONITORING=1\nNO_PROXY=localhost,127.0.0.1,grafana,backend\n');env.chmod(0o600)
  docker('network','create',name)
  docker('volume','create',name+'-grafana-data')
  docker('run','-d','--name',frontend,'--network',name,'--cpus','1','--memory','512m','--memory-swap','512m','--env-file',str(env),'-p','127.0.0.1::3000','--entrypoint','node',front_image,'node_modules/next/dist/bin/next','start','--hostname','0.0.0.0','--port','3000')
  ip=json.loads(docker('inspect',frontend))[0]['NetworkSettings']['Networks'][name]['IPAddress']
  values={'GF_SERVER_HTTP_PORT':'3001','GF_SERVER_HTTP_ADDR':'0.0.0.0','GF_SERVER_ROOT_URL':'/monitoring/','GF_SERVER_SERVE_FROM_SUB_PATH':'true','GF_AUTH_PROXY_ENABLED':'true','GF_AUTH_PROXY_HEADER_NAME':'X-DocLens-Grafana-User','GF_AUTH_PROXY_WHITELIST':ip,'GF_AUTH_PROXY_ENABLE_LOGIN_TOKEN':'false','GF_AUTH_BASIC_ENABLED':'false','GF_AUTH_DISABLE_LOGIN_FORM':'true','GF_AUTH_ANONYMOUS_ENABLED':'false','GF_SECURITY_ADMIN_PASSWORD':uuid.uuid4().hex,'GF_PATHS_PROVISIONING':'/fixture/provisioning','GF_DASHBOARDS_DEFAULT_HOME_DASHBOARD_PATH':'/fixture/dashboards/doclens.json','GF_ANALYTICS_REPORTING_ENABLED':'false','GF_ANALYTICS_CHECK_FOR_UPDATES':'false','GF_ANALYTICS_CHECK_FOR_PLUGIN_UPDATES':'false','GF_PLUGINS_PREINSTALL_DISABLED':'true','GF_LIVE_MAX_CONNECTIONS':'0','GOMEMLIMIT':'256MiB','HTTP_PROXY':'','HTTPS_PROXY':'','ALL_PROXY':''}
  g_env=fixture/'grafana.env';g_env.write_text(''.join(k+'='+v+'\n' for k,v in values.items()));g_env.chmod(0o600)
  docker('run','-d','--name',grafana,'--network',name,'--network-alias','grafana','--cpus','1','--memory','512m','--memory-swap','512m','--env-file',str(g_env),'-v',name+'-grafana-data:/var/lib/grafana','--mount','type=bind,source='+str(fixture/'provisioning')+',target=/fixture/provisioning,readonly','--mount','type=bind,source='+str(dashboard_dir)+',target=/fixture/dashboards,readonly',graf_image)
  port=int(docker('port',frontend,'3000/tcp').rsplit(':',1)[1])
  health=urllib.request.build_opener(urllib.request.ProxyHandler({}));deadline=time.monotonic()+90
  while True:
   try:
    if health.open('http://127.0.0.1:'+str(port)+'/',timeout=2).status==200 and 'HTTP Server Listen' in docker('logs',grafana):break
   except Exception:pass
   assert json.loads(docker('inspect',grafana))[0]['State']['Running'],'Grafana fixture exited'
   assert time.monotonic()<deadline,'Fixture readiness failed'
   time.sleep(.25)
  # Run both original and corrected gateway against the same real dependencies.
  old=fixture/'before.py';old.write_bytes(subprocess.check_output(['git','show','218781e4508e5ca80b35cb07a0297dfe482b8c6d:deploy/runpod/monitoring_gateway.py'],cwd=root))
  for label,path in [('before',old),('after',root/'deploy/runpod/monitoring_gateway.py')]:
   spec=importlib.util.spec_from_file_location('gateway_'+label,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
   server=module.Gateway(('127.0.0.1',0),'grafana',port);servers.append(server)
   public_origin='http://doclens.localhost:'+str(port)
   if label=='after':
    module.prepare_dashboard(template, runtime, public_origin)
    docker('restart',grafana)
    ready_deadline=time.monotonic()+90
    while True:
     check=subprocess.run(['docker','exec',frontend,'node','-e',"fetch('http://grafana:3001/monitoring/api/health').then(r=>process.exit(r.status===200?0:1)).catch(()=>process.exit(1))"],capture_output=True)
     if check.returncode==0:break
     assert time.monotonic()<ready_deadline,'Grafana restart readiness failed'
     time.sleep(.25)
   threading.Thread(target=server.serve_forever,daemon=True).start()
   env_browser=dict(os.environ,DOCLENS_TEST_URL=public_origin,DOCLENS_GRAFANA_URL='http://grafana.localhost:'+str(server.server_port),DOCLENS_TEST_BACK_LINK_ONLY='1',DOCLENS_MONITORING_EVIDENCE=str(out/('browser-'+label)))
   command=['node',str(root/'tests/runpod_links_browser.cjs')]
   with (out/('browser-'+label+'.log')).open('w') as log:
    result=subprocess.run(command,env=env_browser,stdout=log,stderr=subprocess.STDOUT)
   if label=='before':assert result.returncode!=0,'Expected old gateway navigation failure';print('REPRODUCED original browser failure',flush=True)
   else:assert result.returncode==0,'Corrected browser regression failed; see log';print('PASS corrected browser click and destination authentication',flush=True)
   server.shutdown();server.server_close();servers.remove(server)
  config=json.loads(docker('inspect',grafana))[0]
  assert not config['HostConfig']['PortBindings'],'Raw Grafana must stay private'
  (out/'fixture-results.json').write_text(json.dumps({'frontend_image':front_image,'grafana_image':graf_image,'raw_grafana_published':False,'backend_started':False,'grafana_restart_reused_synthetic_database':True,'scope':'targeted actual Grafana + existing production frontend + current gateway; not final RunPod image or provider validation','read_only_fixture_mounts':['Grafana dashboard JSON','Grafana provisioning'],'before':'browser failed','after':'browser passed'},indent=2)+'\n')
finally:
 for server in servers:server.shutdown();server.server_close()
 for container in [grafana,frontend]:
  (out/(container.rsplit('-',1)[1]+'-container.log')).write_text(docker('logs',container,check=False))
  docker('rm','-f',container,check=False)
 docker('network','rm',name,check=False)
 docker('volume','rm',name+'-grafana-data',check=False)
