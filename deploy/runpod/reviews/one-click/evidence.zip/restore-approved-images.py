import json,subprocess,hashlib,shutil
from pathlib import Path
rows=json.loads(Path('/workspace/DocLens-runpod-links-evidence/approved-image-archives.json').read_text())
for row in rows:
 p=Path(row['archive']);h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 assert h.hexdigest()==row['sha256']
 assert shutil.disk_usage('/workspace').free>3*1024**3,'Do not risk disk exhaustion during restore'
 subprocess.run(['docker','--host=unix:///var/run/docker.sock','load','--input',str(p)],check=True)
 actual=subprocess.check_output(['docker','image','inspect',row['tag'],'--format','{{.Id}}'],text=True).strip()
 assert actual==row['image_id']
 print('PASS restored exact original tag and ID:',row['tag'],actual,flush=True)
