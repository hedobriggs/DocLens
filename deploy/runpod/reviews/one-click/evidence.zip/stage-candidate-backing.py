"""Temporary VFS backing relocation for this candidate only; never app volumes.
Run inside an empty diagnostic container with the explicit mounts in its runner.
All bytes, modes, ownership and link targets are checked before/after copying.
The candidate image ID/layer metadata remain unchanged; restore after testing.
"""
import os,sys,json,hashlib,stat,subprocess,shutil
from pathlib import Path
layer_id='ox4k57341kvro7z8aur4x580a'
source=Path('/layers')/layer_id
stage=Path('/tmp/DocLens-candidate-backing')
stage.mkdir(mode=0o700,exist_ok=True)
root=stage/'root'

def digest(directory):
    h=hashlib.sha256(); count=0
    for base,dirs,files in os.walk(directory,followlinks=False):
        for name in sorted(dirs+files):
            p=Path(base)/name; s=p.lstat()
            record=[str(p.relative_to(directory)),stat.S_IMODE(s.st_mode),s.st_uid,s.st_gid]
            if p.is_symlink():record+=['link',os.readlink(p)]
            elif p.is_file():
                fhash=hashlib.sha256()
                with p.open('rb') as stream:
                    while b:=stream.read(1024*1024):fhash.update(b)
                record+=['file',s.st_size,fhash.hexdigest()]
            elif p.is_dir():record+=['directory']
            else:raise RuntimeError('Unexpected special file')
            h.update(json.dumps(record,sort_keys=True).encode()+b'\n');count+=1
        dirs.sort()
    return {'sha256':h.hexdigest(),'entries':count}

if sys.argv[1]=='stage':
    assert source.is_dir() and not source.is_symlink() and not root.exists()
    # Source must be the recorded final-image chain, not a container layer.
    # Actual metadata reference is passed by runner after computing all diff IDs.
    chain=Path('/references/sha256')/sys.argv[2]
    assert (chain/'cache-id').read_text().strip()==layer_id
    before=digest(source)
    root.mkdir(mode=0o700)
    subprocess.run(['/usr/bin/cp','-a',str(source)+'/.',str(root)+'/'],check=True)
    after=digest(root);assert before==after
    backup=source.with_name(layer_id+'.current-task-backup');assert not backup.exists()
    source.rename(backup)
    source.symlink_to(root,target_is_directory=True)
    assert digest(source)==before
    (stage/'verification.json').write_text(json.dumps({'image_id':'sha256:72ee8d9178cda195de99457618b3bf2c563dc4ca94fbd5074cc0e3e05a3bf99c','root_id':layer_id,'verification':before,'status':'staged'},indent=2)+'\n')
    shutil.rmtree(backup)
    print('PASS candidate-only backing staged; contents/modes/ownership/link targets verified',before)
elif sys.argv[1]=='restore':
    assert source.is_symlink() and source.readlink()==root
    reference=json.loads((stage/'verification.json').read_text())['verification']
    assert digest(root)==reference
    restored=source.with_name(layer_id+'.restored');assert not restored.exists()
    restored.mkdir(mode=0o700)
    subprocess.run(['/usr/bin/cp','-a',str(root)+'/.',str(restored)+'/'],check=True)
    assert digest(restored)==reference
    source.unlink();restored.rename(source)
    assert digest(source)==reference
    print('PASS candidate backing restored; exact contents/modes/ownership/link targets verified')
else:raise SystemExit('Invalid mode')
