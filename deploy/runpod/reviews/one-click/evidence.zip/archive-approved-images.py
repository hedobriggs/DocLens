import subprocess,json,gzip,hashlib,tarfile,shutil
from pathlib import Path
out=Path('/tmp/DocLens-approved-image-archives');out.mkdir(mode=0o700,exist_ok=True)
images=[('doclens-monitoring-frontend:acceptance','sha256:51cccc5c8c060942df5409facf7f51dd62632467c62e38b5ba5fc72bf321bc5e'),('doclens-mac-ui-candidate:review','sha256:cf241ebaede03f9bc43feb4c686834baf139833b70e1842dbc55627378c9cffb')]
results=[]
for tag,identity in images:
 x=json.loads(subprocess.check_output(['docker','--host=unix:///var/run/docker.sock','image','inspect',tag]))[0]
 assert x['Id']==identity and x['RepoTags']==[tag]
 assert not subprocess.check_output(['docker','ps','-aq','--filter','ancestor='+identity]).strip()
 assert shutil.disk_usage(out).free>x['Size']+1024**3
 target=out/(tag.replace(':','-')+'.tar.gz');assert not target.exists()
 with target.open('wb') as dest:
  save=subprocess.Popen(['docker','--host=unix:///var/run/docker.sock','image','save',tag],stdout=subprocess.PIPE)
  with gzip.GzipFile(fileobj=dest,mode='wb',compresslevel=1) as zipped:shutil.copyfileobj(save.stdout,zipped)
  assert save.wait()==0
 with tarfile.open(target,'r:gz') as archive:
  manifest=json.load(archive.extractfile('manifest.json'))
  assert len(manifest)==1 and manifest[0]['RepoTags']==[tag]
  config=archive.extractfile(manifest[0]['Config']).read()
  assert 'sha256:'+hashlib.sha256(config).hexdigest()==identity
 h=hashlib.sha256()
 with target.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 results.append({'tag':tag,'image_id':identity,'archive':str(target),'archive_bytes':target.stat().st_size,'sha256':h.hexdigest(),'manifest_config_verified':True})
 print('PASS archive verified:',tag,flush=True)
# Both archives must pass before either image is removed.
for tag,identity in images:
 assert not subprocess.check_output(['docker','ps','-aq','--filter','ancestor='+identity]).strip()
 subprocess.run(['docker','--host=unix:///var/run/docker.sock','image','rm',tag],check=True)
 print('PASS removed only approved local tag:',tag,flush=True)
Path('/workspace/DocLens-runpod-links-evidence/approved-image-archives.json').write_text(json.dumps(results,indent=2)+'\n')
print('Free bytes:',shutil.disk_usage('/workspace').free)
