import subprocess,json,hashlib,tarfile,io
from pathlib import Path
x=json.loads(subprocess.check_output(['docker','image','inspect','doclens-runpod-links:review']))[0]
assert x['Id']=='sha256:72ee8d9178cda195de99457618b3bf2c563dc4ca94fbd5074cc0e3e05a3bf99c'
assert not subprocess.check_output(['docker','ps','-aq']).strip(),'Do not change backing with containers present'
import sys
mode=sys.argv[1]
if mode=='stage':
 with tarfile.open('/tmp/DocLens-approved-image-archives/current-candidate.tar.gz','r:gz') as archive:
  manifest=json.load(archive.extractfile('manifest.json'))
  config=archive.extractfile(manifest[0]['Config']).read()
  assert 'sha256:'+hashlib.sha256(config).hexdigest()==x['Id']
 b=io.BytesIO()
 with tarfile.open(fileobj=b,mode='w'):pass
 subprocess.run(['docker','import','-','doclens-links-recovery:temporary'],input=b.getvalue(),check=True)
chain=x['RootFS']['Layers'][0]
for diff in x['RootFS']['Layers'][1:]:chain='sha256:'+hashlib.sha256((chain+' '+diff).encode()).hexdigest()
stage=Path('/tmp/DocLens-candidate-backing');stage.mkdir(mode=0o700,exist_ok=True)
cmd=['docker','run','--rm','--network','none','--read-only']
for src,dst,readonly in [('/usr','/usr',True),('/lib','/lib',True),('/lib64','/lib64',True),('/var/lib/docker/image/vfs/layerdb','/references',True),('/var/lib/docker/vfs/dir','/layers',False),(str(stage),str(stage),False),('/workspace/DocLens-runpod-links-evidence/stage-candidate-backing.py','/helper.py',True)]:
 cmd+=['--mount','type=bind,source='+src+',target='+dst+(',readonly' if readonly else '')]
cmd+=['doclens-links-recovery:temporary','/usr/bin/python3','/helper.py',mode,chain.split(':')[1]]
print('COMMAND',repr(cmd),flush=True)
subprocess.run(cmd,check=True)
