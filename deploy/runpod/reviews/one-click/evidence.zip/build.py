from pathlib import Path
import os,json,hashlib,subprocess,tempfile
r=Path('/workspace/DocLens');out=Path(__file__).parent
with tempfile.TemporaryDirectory(prefix='doclens-links-build-') as t:
 c=Path(t)
 for name,digest in json.loads((r/'deploy/portable/application-manifest.json').read_text())['sha256'].items():
  if not name.startswith('frontend/'):continue
  b=(r/name).read_bytes();assert hashlib.sha256(b).hexdigest()==digest,name
  p=c/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 cmd=['docker','--host=unix:///var/run/docker.sock','build','--platform','linux/amd64','--secret','id=build_ca,src=/etc/ssl/certs/ca-certificates.crt','-f',str(r/'deploy/portable/Dockerfile.frontend'),'-t','doclens-runpod-links-frontend:review',str(c/'frontend')]
 with (out/'frontend-build.log').open('w') as f:
  f.write('COMMAND '+repr(cmd)+'\n');f.flush();subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
cmd=['docker','--host=unix:///var/run/docker.sock','build','--platform','linux/amd64','--build-arg','FRONTEND_IMAGE=doclens-runpod-links-frontend:review','--build-arg','BACKEND_IMAGE=doclens-d909540-backend:acceptance','-f','deploy/runpod/Dockerfile','-t','doclens-runpod-links:review','.']
with (out/'image-build.log').open('w') as f:
 f.write('COMMAND '+repr(cmd)+'\n');f.flush();subprocess.run(cmd,cwd=r,stdout=f,stderr=subprocess.STDOUT,check=True)
print('PASS frontend and final image builds')
