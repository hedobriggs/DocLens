import importlib.util,tempfile,json,zipfile,os,collections,subprocess,hashlib,shutil
from pathlib import Path
from unittest.mock import patch
p='/workspace/DocLens/deploy/runpod/reviews/mac-a2986c7-security/focused-acceptance.py';s=importlib.util.spec_from_file_location('focus',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
secret='SYNTHETIC_FOCUS_REDACTION_CHECK'
for mode in ['failure','zero-without-results','success']:
 with tempfile.TemporaryDirectory() as td:
  root=Path(td);shutil.copyfile('/workspace/attachments/a4eff197-636e-4910-bfa2-ad57eaad42b3/focus.66Jlsq.zip',root/'focus.66Jlsq.zip');out=root/('focus.'+mode);out.mkdir();source=root/'source';(source/'deploy/portable').mkdir(parents=True);(source/'deploy/portable/smoke.py').write_text("def pdf(pages): return b'%PDF synthetic fixture'\n");(source/'frontend/node_modules/playwright').mkdir(parents=True);(root/'acceptance.vW5s1h/browser-cache').mkdir(parents=True)
  def read(args):
   if args[0]=='git':return m.COMMIT if 'rev-parse'in args else ''
   if args[:3]==['docker','context','inspect']:return 'unix:///synthetic.sock'
   if args[:3]==['docker','image','inspect']:return m.IMAGE
   if args[:2]==['docker','info']:return '8 4101181440'
   if args==['docker','ps','-q']:return ''
   if args[:3]==['docker','ps','-a']:return 'existing original exited'
   if args[:3]==['docker','volume','ls']:return 'original-volume'
   return 'v25-synthetic'
  def run(command,**kwargs):
   kwargs['stdout'].write(secret+' retained original failure/log\n')
   if mode=='success':(out/'results.json').write_text(json.dumps({'image':m.IMAGE,'scenarios':[{'scenario':name,'status':'PASS'}for name in ['upload-401','question-401','question-clock']],'monitoring':{'grafana':{'status':'PASS'},'prometheus':{'status':'PREVIOUSLY_PASSED'}}}))
   return subprocess.CompletedProcess(command,1 if mode=='failure'else 0)
  with patch.object(m,'ROOT',root),patch.object(m,'SOURCE',source),patch.object(m,'OUT',out),patch.object(m,'read',read),patch.object(m.platform,'system',return_value='Darwin'),patch.object(m.platform,'machine',return_value='x86_64'),patch.object(m.platform,'platform',return_value='syntheticMac'),patch.object(m.shutil,'disk_usage',return_value=collections.namedtuple('Disk','total used free')(50*1024**3,1,40*1024**3)),patch.object(m.subprocess,'run',run),patch.dict(os.environ,{'GEMINI_API_KEY':secret},clear=False):
   try:m.main()
   except SystemExit as e:assert e.code==(0 if mode=='success'else 1)
   archive=out.parent/(out.name+'.zip');assert archive.exists();assert secret in (out/'browser.log').read_text()
   with zipfile.ZipFile(archive) as z:assert all(secret.encode() not in z.read(n) for n in z.namelist())
   state=json.loads((out/'host-results.json').read_text());assert state['status']==('PASS'if mode=='success'else 'BLOCKED'if mode=='zero-without-results'else 'FAIL');assert all(state['preexisting_preserved'].values())
   h=hashlib.sha256(archive.read_bytes()).hexdigest()
   try:m.main()
   except SystemExit:pass
   assert hashlib.sha256(archive.read_bytes()).hexdigest()==h
print('PASS mocked failed-run retention, zero-exit/missing-evidence rejection, complete expected-evidence acceptance, archive redaction and unique naming, same-attempt overwrite refusal, and existing-object inventory preservation. No image/browser execution.')
