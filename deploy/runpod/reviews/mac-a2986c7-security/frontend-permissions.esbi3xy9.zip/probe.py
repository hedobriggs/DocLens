
import hashlib, json, os, pathlib, stat
out = {'euid': os.geteuid(), 'egid': os.getegid(), 'files': []}
for name in ['/opt/frontend/package.json', '/opt/frontend/next.config.ts']:
    p = pathlib.Path(name); row = {'path': name}
    try:
        s = p.lstat()
        row.update(mode=oct(stat.S_IMODE(s.st_mode)), uid=s.st_uid,
                   gid=s.st_gid, regular=stat.S_ISREG(s.st_mode))
        if not stat.S_ISREG(s.st_mode):
            row['read_skipped'] = 'not a regular file'
        else:
            with p.open('rb') as f:
                data = f.read(1024 * 1024 + 1)
            if len(data) > 1024 * 1024:
                row['read_skipped'] = 'exceeds inspection bound'
            else:
                row.update(bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                           elf=data.startswith(b'\x7fELF'))
    except OSError as e:
        row.update(exception=type(e).__name__, errno=e.errno, message=e.strerror)
    out['files'].append(row)
print(json.dumps(out, indent=2))
