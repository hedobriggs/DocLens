
const {createRequire}=require('node:module');
const path=require('node:path');
const req=createRequire(path.join(process.env.DOCLENS_ACCEPTANCE_SOURCE,'frontend/package.json'));
const {chromium}=req('playwright');
const launch=chromium.launch.bind(chromium);
chromium.launch=options=>launch({...options,executablePath:chromium.executablePath(),args:[...(options.args||[]),'--host-resolver-rules=MAP doclens.localhost 127.0.0.1, MAP grafana.localhost 127.0.0.1, MAP prometheus.localhost 127.0.0.1']});
