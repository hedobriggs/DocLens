
import hashlib, json, os, pathlib, time
roots = ['/usr/local/bin', '/usr/local/sbin', '/usr/bin', '/usr/sbin', '/usr/lib', '/usr/lib64', '/opt/qdrant/lib']
out = {'roots': roots, 'files': [], 'errors': [], 'symlinks': [], 'bounded_stop': None}
start = time.monotonic(); total = 0; seen = set()
markers = [b'zipOpenNewFileInZip4_64', b'unzOpen64', b'sqlite3KeyInfoFromExprList']
class Budget(Exception): pass
def check():
    if time.monotonic() - start > 120 or total >= 2 * 1024**3 or len(seen) >= 10000:
        raise Budget('120 seconds / 2 GiB native bytes / 10000 native files limit')
def error(e):
    out['errors'].append({'path': e.filename, 'exception': type(e).__name__, 'errno': e.errno})
try:
    for root in roots:
        for directory, dirs, names in os.walk(root, onerror=error, followlinks=False):
            check()
            # Do not silently treat skipped directory symlinks as scanned.
            for name in dirs:
                p = pathlib.Path(directory) / name
                if p.is_symlink(): out['symlinks'].append({'path': str(p), 'target': os.readlink(p)})
            for name in names:
                check(); p = pathlib.Path(directory) / name
                try:
                    if p.is_symlink():
                        out['symlinks'].append({'path': str(p), 'target': os.readlink(p)})
                        continue
                    if not p.is_file(): continue
                    with p.open('rb') as f:
                        if f.read(4) != b'\x7fELF': continue
                        key = (p.stat().st_dev, p.stat().st_ino)
                        if key in seen: continue
                        seen.add(key); f.seek(0); h = hashlib.sha256(); found = set(); tail = b''
                        while True:
                            check(); block = f.read(1024 * 1024)
                            if not block: break
                            total += len(block); h.update(block); window = tail + block
                            found.update(m.decode() for m in markers if m in window)
                            tail = window[-128:]
                    out['files'].append({'path': str(p), 'bytes': p.stat().st_size,
                        'sha256': h.hexdigest(), 'markers': sorted(found)})
                except OSError as e: error(e)
except Budget as e: out['bounded_stop'] = str(e)
out.update(elapsed_seconds=time.monotonic()-start, native_bytes_read=total)
out['coverage_complete'] = out['bounded_stop'] is None and not out['errors']
out['limitations'] = 'Symlinks are recorded, not followed. Missing markers do not prove absent static/stripped code. Selected roots only.'
print(json.dumps(out, indent=2))
