
import hashlib, importlib.metadata, json, os, pathlib, sqlite3, subprocess, zlib
out = {'sqlite_runtime': sqlite3.sqlite_version, 'zlib_runtime': zlib.ZLIB_RUNTIME_VERSION,
       'sqlite_compile_options': list(sqlite3.connect(':memory:').execute('pragma compile_options')),
       'packages': [], 'native_files': [], 'errors': []}
out['dpkg'] = subprocess.run(['dpkg-query', '-W', '-f=${binary:Package}\t${Version}\n'],
    capture_output=True, text=True, check=True).stdout
for d in importlib.metadata.distributions():
    out['packages'].append({'name': d.metadata['Name'], 'version': d.version})
markers = [b'zipOpenNewFileInZip4_64', b'zipOpenNewFileInZip4', b'unzOpen64',
           b'sqlite3KeyInfoFromExprList', b'SQLite format 3']
roots = ['/usr/local/lib', '/usr/lib/x86_64-linux-gnu', '/opt/qdrant',
         '/opt/grafana', '/opt/prometheus', '/opt/frontend']
seen = set()
for root in roots:
    for directory, _, files in os.walk(root):
        for name in files:
            p = pathlib.Path(directory) / name
            try:
                if p.is_symlink(): continue
                with p.open('rb') as f:
                    if f.read(4) != b'\x7fELF': continue
                    real = str(p.resolve())
                    if real in seen: continue
                    seen.add(real); f.seek(0); digest = hashlib.sha256(); found = set(); tail = b''
                    while True:
                        block = f.read(1024 * 1024)
                        if not block: break
                        digest.update(block); window = tail + block
                        found.update(m.decode() for m in markers if m in window)
                        tail = window[-128:]
                out['native_files'].append({'path': str(p), 'bytes': p.stat().st_size,
                    'sha256': digest.hexdigest(), 'markers': sorted(found)})
            except (OSError, ValueError) as e:
                out['errors'].append({'path': str(p), 'exception': type(e).__name__})
out['loaded_mappings_after_sqlite_import'] = pathlib.Path('/proc/self/maps').read_text()
print(json.dumps(out, indent=2))
