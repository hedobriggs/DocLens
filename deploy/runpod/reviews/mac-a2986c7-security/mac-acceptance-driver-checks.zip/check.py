import importlib.util,tempfile,json,zipfile,hashlib,os,collections
from pathlib import Path
from unittest.mock import patch
p=Path('/workspace/DocLens/deploy/runpod/reviews/mac-a2986c7-security/mac-acceptance.py');s=importlib.util.spec_from_file_location('driver',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
compile(m.NATIVE,'native','exec');compile(m.DEPENDENCIES,'dependencies','exec')
secret='SYNTHETIC_REDACTION_CHECK'
with tempfile.TemporaryDirectory() as td:
 root=Path(td);out=root/'acceptance.first';out.mkdir();source=root/'source';(source/'tests').mkdir(parents=True)
 for n in ['test_dependency_network.py','test_dependency_config.py','test_dependency_framework.py']:(source/'tests'/n).write_text('# synthetic fixture\n')
 def read(args):
  if args[0]=='git':return m.COMMIT if 'rev-parse'in args else ''
  if args[:3]==['docker','context','inspect']:return 'unix:///synthetic.sock'
  if args[:3]==['docker','image','inspect']:return m.IMAGE
  if args[:2]==['docker','info']:return '8 4101177344'
  if args==['docker','ps','-q']:return ''
  if args[:3]==['docker','ps','-a']:return 'existing original exited'
  if args[:3]==['docker','volume','ls']:return 'original-volume'
  return 'synthetic-version'
 class Process:
  def __init__(self,command,**kwargs):
   self.returncode=1 if command[0]=='npm' else (137 if command[-1]=='-' else 0)
   kwargs['stdout'].write(secret+' synthetic failure retained\n')
  def communicate(self,input=None):pass
 with patch.object(m,'ROOT',root),patch.object(m,'SOURCE',source),patch.object(m,'OUT',out),patch.object(m,'read',read),patch.object(m.platform,'system',return_value='Darwin'),patch.object(m.platform,'machine',return_value='x86_64'),patch.object(m.platform,'platform',return_value='syntheticMac'),patch.object(m.shutil,'which',return_value='/synthetic/bin'),patch.object(m.shutil,'disk_usage',return_value=collections.namedtuple('Disk','total used free')(50*1024**3,1,40*1024**3)),patch.object(m.subprocess,'Popen',Process),patch.dict(os.environ,{'GEMINI_API_KEY':secret},clear=False):
  try:m.main()
  except SystemExit as e:assert e.code==1
  else:raise AssertionError('Expected retained failed run')
  archive=root/'acceptance.first.zip';assert archive.exists() and not (root/'acceptance.zip').exists()
  assert secret in (out/'private-raw'/'baked-native.log').read_text()
  with zipfile.ZipFile(archive) as z:assert all(secret.encode() not in z.read(n)for n in z.namelist())
  data=json.loads((out/'results.json').read_text());assert data['complete_acceptance'] is False and data['results']['baked-native']['exit']==137 and all(data['preexisting_preserved'].values())
  before=hashlib.sha256(archive.read_bytes()).hexdigest()
  try:m.main()
  except SystemExit:pass
  assert hashlib.sha256(archive.read_bytes()).hexdigest()==before
print('PASS syntax; mocked failures preserved; private raw log retained; portable archive key redaction; unique archive name; same-attempt overwrite refused; pending gates explicit; preexisting inventories preserved. No Docker acceptance executed.')
