import sys,sqlite3,ssl,unittest,importlib.metadata,json
print(json.dumps({'scope':'base compatibility with mounted approved CPU dependencies; NOT final-image acceptance','python':sys.version,'sqlite':sqlite3.sqlite_version,'tls':ssl.OPENSSL_VERSION}),flush=True)
assert sys.version_info[:2]==(3,11) and sqlite3.sqlite_version_info>=(3,41,2)
suite=unittest.defaultTestLoader.loadTestsFromNames(['test_dependency_network','test_dependency_config','test_dependency_framework','test_mac_upload_limits','test_mac_document_coverage'])
r=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(not r.wasSuccessful())
