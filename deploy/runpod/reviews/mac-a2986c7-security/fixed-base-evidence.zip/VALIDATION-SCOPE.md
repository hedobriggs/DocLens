# Fixed base compatibility evidence

Executed against pinned official Python amd64 base 6d10e720318bd84cc3d88af92bb5a47189222e17620a2fd214da6445e4afb679, not a rebuilt DocLens image. Host-authorized synthetic dependencies/models/source fixtures were mounted read-only; no application volumes, customer data, credentials, public ports or Docker socket were mounted. Tests run as UID 1000 with cap-drop ALL, no-new-privileges, read-only filesystem, network none, tmpfs-only synthetic writes, 2 CPU/2 GiB/pids128 bounds.

Commands and input scripts retained in compatibility-command.json / compatibility-probe.py and native-inference-command.json / native-inference-probe.py. Dependency site-packages are the previously installed approved 73-package CPU graph, not a fresh install on this base. Mount sources are synthetic test assets, not runtime substitutions presented as final-image acceptance. No performance claims for the Intel Mac or whole stack.

Compatibility: 67 unittest executions passed (includes inherited/repeated upload fixture cases; not 67 distinct security advisories). Suites: test_dependency_network, test_dependency_config, test_dependency_framework, test_mac_upload_limits, test_mac_document_coverage. Real PDF/local Qdrant semantics, failed replacements/cancellation/limits, TLS local synthetic CA rejection/acceptance/wrong-host, ASGI auth and controlled synthetic generation are tested. No remote Qdrant server/browser/Gemini/public HTTPS/monitoring/full Compose tests are represented.

Native: real pinned CPU models loaded and embedded/reranked five synthetic employers. vectors and queries and reranker scores match earlier candidate outputs exactly, max absolute delta 0.0 (threshold 1e-4); model-output-comparison.json. Model revisions unchanged. This proves compatibility for the mounted graph and specific fixtures, not all native code paths.

Packaging: python3 -m unittest discover -s deploy/portable -p test_packaging.py -v passed six checks. Source-integrity guard and application manifest unchanged. Model pins/limits/data-handling paths preserved; preservation-checks.json hashes match a2986c7.

All commands in this compatibility run passed; no failed run/retry occurred to hide. Earlier failed vendor metadata/readelf/Go attempts and original Mac failed reads remain in prior evidence ZIPs, not replaced. Whole-image build/scan/acceptance is pending: local Docker filesystem has only 5.0 GiB free and final image is absent. No image ID for a rebuilt DocLens candidate is claimed.
