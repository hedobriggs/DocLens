import sys
sys.argv=["base-model-probe", "/tmp/models.json"]
import sys,json,time,resource
import numpy as np
import torch
from sentence_transformers import SentenceTransformer,CrossEncoder
from importlib.metadata import version
texts=['Aster Research employed Alex as a research analyst.','Birch Analytics employed Alex as a data engineer.','Cobalt Systems employed Alex as a support specialist.','Delta Robotics employed Alex as a technical consultant.','Elm Computing employed Alex as a systems administrator.']
queries=['Where did Alex work as a research analyst?','Who employed Alex as a systems administrator?','List all organizations that employed Alex.']
torch.set_num_threads(2);torch.set_num_interop_threads(1)
start=time.monotonic();model=SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2',device='cpu');load=time.monotonic()-start
vectors=model.encode(texts,convert_to_numpy=True);q=model.encode(queries,convert_to_numpy=True)
reranker=CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v2',device='cpu')
scores=reranker.predict([(queries[0],t)for t in texts]).tolist()
assert vectors.shape==(5,384) and np.isfinite(vectors).all()
assert sorted(range(5),key=lambda i:scores[i],reverse=True)[0]==0
payload={'versions':{p:version(p)for p in ['torch','transformers','sentence-transformers','huggingface-hub','numpy']},'vectors':vectors.tolist(),'queries':q.tolist(),'reranker_scores':scores,'load_seconds':load,'elapsed_seconds':time.monotonic()-start,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'threads':2,'model_revisions':['1110a243fdf4706b3f48f1d95db1a4f5529b4d41','233902d25c440f23af6f7d6e94d2946bac0bee0a']}
open(sys.argv[1],'w').write(json.dumps(payload,indent=2)+'\n');print('PASS real CPU model loading, finite 384D embeddings and expected top employer; measurements recorded')

print(open("/tmp/models.json").read())
