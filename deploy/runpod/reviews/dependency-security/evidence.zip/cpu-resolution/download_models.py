from pathlib import Path
import hashlib,json
from huggingface_hub import snapshot_download
models=[('sentence-transformers/all-MiniLM-L6-v2','1110a243fdf4706b3f48f1d95db1a4f5529b4d41'),('cross-encoder/ms-marco-MiniLM-L-6-v2','233902d25c440f23af6f7d6e94d2946bac0bee0a')]
results=[]
for repo,revision in models:
 snapshot=Path(snapshot_download(repo,revision=revision,allow_patterns=['*.json','*.safetensors','vocab.txt'],token=False))
 refs=snapshot.parent.parent/'refs';refs.mkdir(exist_ok=True);(refs/'main').write_text(revision)
 files={str(p.relative_to(snapshot)):hashlib.sha256(p.read_bytes()).hexdigest()for p in snapshot.rglob('*')if p.is_file()}
 results.append({'repo':repo,'revision':revision,'files':files})
Path('/workspace/DocLens-cpu-resolution/model-manifest.json').write_text(json.dumps(results,indent=2)+'\n')
print('PASS two fixed model snapshots downloaded; hashes recorded; no provider or customer data')
