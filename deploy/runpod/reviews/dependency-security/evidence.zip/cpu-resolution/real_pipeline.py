from pathlib import Path
import os,sys,json,time,resource,tempfile,logging
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch
os.environ['DOCLENS_SESSION_SECRET']='synthetic-cpu-retest-secret'
os.environ['GEMINI_API_KEY']='synthetic-not-a-provider-key'
sys.path.insert(0,'/workspace/DocLens/backend')
import fitz
from fastapi.testclient import TestClient
from qdrant_client import QdrantClient
start=time.monotonic()
with patch('qdrant_client.QdrantClient'):
 import main,vector_store
from embeddings import create_embedding
headers={'X-DocLens-Internal-Key':os.environ['DOCLENS_SESSION_SECRET']}
employers=['Aster Research','Birch Analytics','Cobalt Systems','Delta Robotics','Elm Computing']
with tempfile.TemporaryDirectory() as tmp:
 vector_store.client=QdrantClient(path=tmp,force_disable_check_same_thread=True)
 with TestClient(main.app) as api:
  def pdf(dense=False):
   with fitz.open() as doc:
    if dense:
     for p in range(32):
      page=doc.new_page()
      for line in range(70):
       page.insert_text((25,25+line*10),f'Synthetic contract {p}-{line}: {employers[(p+line)%5]} requires written notice and records review before renewal.',fontsize=7)
    else:
     for name in employers:doc.new_page().insert_text((30,40),'Employer: '+name+'. Synthetic work history for Alex.')
    return doc.tobytes()
  def upload(data,name):return api.post('/documents/process',headers=headers,files={'file':(name,data,'application/pdf')})
  baseline=json.load(open('/workspace/DocLens-cpu-resolution/models-baseline.json'))
  old_chunks=[{'text':'Employer: '+name, 'metadata':{'document_name':'baseline-vector.pdf','page_number':i+1,'chunk_id':f'p{i+1}-c1'}}for i,name in enumerate(employers)]
  vector_store.store_chunks(old_chunks,baseline['vectors'])
  old_results=vector_store.hybrid_search('Where did Alex work as a research analyst?',create_embedding('Where did Alex work as a research analyst?'),limit=3,document_name='baseline-vector.pdf')
  assert 'Aster Research' in str(old_results[0]),old_results
  cv=pdf();response=upload(cv,'synthetic-cv.pdf');assert response.status_code==200,response.text
  rows=vector_store.hybrid_search('Which organization is Aster Research?',create_embedding('Which organization is Aster Research?'),limit=3,document_name='synthetic-cv.pdf')
  assert rows and 'Aster Research' in str(rows[0]),rows
  dense=pdf(True)
  with fitz.open(stream=dense,filetype='pdf')as doc:text_chars=sum(len(p.get_text())for p in doc);assert len(doc)==32 and text_chars>200000
  elapsed=[];begin=time.monotonic()
  with ThreadPoolExecutor()as pool:
   future=pool.submit(upload,dense,'dense-synthetic.pdf')
   while not future.done():
    t=time.monotonic();check=api.get('/');elapsed.append(time.monotonic()-t);assert check.status_code==200
    # Declared 20Hz sampling: wait for completion or the next sample, never
    # busy-loop thousands of probes or use a delay as a readiness assertion.
    try:future.result(timeout=.05)
    except TimeoutError:pass
    if time.monotonic()-begin>95:raise AssertionError('Measured ingestion deadline exceeded')
   response=future.result()
  assert response.status_code==200,response.text
  processing=time.monotonic()-begin
  assert max(elapsed)<1.0,max(elapsed)
  def snapshot():return sorted((str(p.id),p.payload)for p in vector_store.client.scroll('document_chunks',limit=10000,with_vectors=False)[0])
  before=snapshot();failed=upload(b'not-a-pdf','dense-synthetic.pdf');assert failed.status_code==400
  assert snapshot()==before
  result={'scope':'real CPU models and PDF/API; local synthetic Qdrant; constructor patched only during import; no Gemini request/full container',
   'pdf_pages':32,'pdf_bytes':len(dense),'extracted_characters':text_chars,'indexed_chunks':response.json()['total_chunks'],
   'processing_seconds':processing,'health_probe_count':len(elapsed),'max_health_seconds':max(elapsed),
   'p95_health_seconds':sorted(elapsed)[int(.95*(len(elapsed)-1))],
   'max_process_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
   'elapsed_seconds':time.monotonic()-start,'failed_replacement':'400; exact synthetic point IDs and payloads preserved',
   'retrieval':'Aster Research ranked first with real cross-encoder against both baseline-vector index and newly ingested CV; five synthetic employer pages ingested'}
  Path('/workspace/DocLens-cpu-resolution/real-pipeline.json').write_text(json.dumps(result,indent=2)+'\n')
 vector_store.client.close()
print('PASS real dense synthetic ingestion, API responsiveness, reranking and failed-replacement preservation')
