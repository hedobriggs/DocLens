// Synthetic real form authentication against the rebuilt Next production server.
const {createRequire}=require('node:module');
const path=require('node:path'),fs=require('node:fs'),crypto=require('node:crypto');
const {spawn}=require('node:child_process');
const root=process.env.DOCLENS_REPO||'/workspace/DocLens';
const output=__dirname,req=createRequire(path.join(root,'frontend/package.json'));
const {chromium}=req('playwright'),{expect}=req('@playwright/test');
let server,browser;
(async()=>{
 const net=require('node:net'),reservation=net.createServer();
 await new Promise(r=>reservation.listen(0,'127.0.0.1',r));
 const port=reservation.address().port;await new Promise(r=>reservation.close(r));
 const log=fs.openSync(path.join(output,'auth-next.log'),'w');
 const secret=crypto.randomBytes(32).toString('hex');
 server=spawn('node',['node_modules/next/dist/bin/next','start','--hostname','127.0.0.1','--port',String(port)],{
  cwd:path.join(root,'frontend'),env:{...process.env,DOCLENS_ADMIN_EMAIL:'trial@synthetic.invalid',
   DOCLENS_ADMIN_PASSWORD_HASH:req('bcryptjs').hashSync('Synthetic-Only-Password-2026',12),
   DOCLENS_SESSION_SECRET:secret,DOCLENS_MONITORING:'1',NEXT_TELEMETRY_DISABLED:'1'},stdio:['ignore',log,log]});
 const base='http://localhost:'+port;
 await expect.poll(async()=>{if(server.exitCode!==null)throw Error('Next exited');try{return(await fetch('http://127.0.0.1:'+port)).status}catch{return 0}},{timeout:20000}).toBe(200);
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
 const context=await browser.newContext(),page=await context.newPage();
 for(const prefix of ['/monitoring','/prometheus']){
  const response=await context.request.get(base+prefix+'/api/query',{maxRedirects:0});
  expect(response.status()).toBe(401);
 }
 await page.goto(base+'/dashboard');await expect(page.getByLabel('Email',{exact:true})).toBeVisible();
 await page.getByLabel('Email',{exact:true}).fill('trial@synthetic.invalid');
 await page.getByLabel('Password',{exact:true}).fill('Wrong-synthetic-password');
 let response=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/auth/login');
 await page.getByRole('button',{name:'Sign in',exact:true}).click();expect((await response).status()).toBe(401);
 await page.getByLabel('Password',{exact:true}).fill('Synthetic-Only-Password-2026');
 response=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/auth/login');
 await page.getByRole('button',{name:'Sign in',exact:true}).click();expect((await response).status()).toBe(200);
 await page.waitForURL('**/dashboard');await expect(page.getByRole('button',{name:'+ Upload PDF',exact:true})).toBeVisible();
 const cookie=(await context.cookies()).find(c=>c.name==='doclens_session');
 expect(cookie.httpOnly).toBe(true);expect(cookie.secure).toBe(true);expect(cookie.sameSite).toBe('Lax');
 expect(cookie.domain).toBe('localhost');
 await page.screenshot({path:path.join(output,'auth-dashboard.png'),fullPage:true});
 await page.getByRole('button',{name:'Log out',exact:true}).click();
 await expect(page.getByLabel('Email',{exact:true})).toBeVisible();
 expect((await context.cookies()).some(c=>c.name==='doclens_session')).toBe(false);
 fs.writeFileSync(path.join(output,'auth-results.json'),JSON.stringify({
  next:req('next/package.json').version,anonymousMonitoring:'401 both services',invalidLogin:401,
  validLogin:200,cookie:'host-only Secure HttpOnly SameSite=Lax',logout:'passed',
  scope:'production Next process, real browser form; no backend/Gemini or raw monitoring service; localhost HTTP is not provider HTTPS'
 },null,2)+'\n');console.log('PASS real production form login/rejection, monitoring anonymous denial, session flags and logout');
})().catch(e=>{console.error(e);process.exitCode=1;}).finally(async()=>{if(browser)await browser.close();if(server)server.kill('SIGTERM');});
