"""Continue unexecuted acceptance after a strict citation-set harness failure.
Fresh setup is necessary: the failed suite cleaned up its own fixture.
No app files are modified or substituted. Already-passed admission/UI regressions
are not rerun. Relevant negative evidence on page 3 is allowed, not education p7.
"""
from pathlib import Path
import os,sys,json,tempfile,subprocess,time,hashlib,re,urllib.request,urllib.error
out=Path(__file__).parent;root=Path('/workspace/DocLens')
prefix=(root/'tests/test_runpod.py').read_text().split('\ntry:\n')[0]
prefix=prefix.replace("    result = subprocess.run(['docker', *args], text=True, capture_output=True)","    result = subprocess.run(['docker', *args], text=True, capture_output=True)\n    with open('/workspace/DocLens-d909540-acceptance/direct-continuation/commands.log','a') as log:\n        log.write('$ docker '+' '.join(args)+'\\n'+result.stdout+result.stderr+'\\nEXIT '+str(result.returncode)+'\\n')")
ns={'__file__':str(root/'tests/test_runpod.py')};exec(compile(prefix,'<committed acceptance helpers>','exec'),ns)
docker=ns['docker'];name=ns['name'];volume=ns['volume'];wait=ns['wait'];request=ns['request'];upload=ns['upload'];records=ns['records'];monitor=ns['monitor'];metric=ns['metric'];pdf=ns['pdf'];employers=ns['EMPLOYERS']
image='sha256:ce23cbb8278ab8ede485603d606340c065df280202788c959517a15079329f27'
texts=['Employer: '+employers[0],'Employer: '+employers[1],'Client: Nimbus Partners. Vendor: Orion tools. Neither is an employer.',*['Employer: '+e for e in employers[2:]],'Education: Synthetic University.']
private=tempfile.TemporaryDirectory(prefix='doclens-acceptance-secret-');envfile=Path(private.name)/'initial.env';envfile.write_text('DOCLENS_ADMIN_EMAIL=trial@synthetic.invalid\nDOCLENS_ADMIN_PASSWORD=Synthetic-$literal-Password-2026\nGEMINI_API_KEY='+os.environ['GEMINI_API_KEY']+'\n');envfile.chmod(0o600)
args=['run','-d','--name',name,'--cpus','2','--memory','4g','--memory-swap','4g','--env-file',str(envfile),'-v',volume+':/workspace','-v','/etc/ssl/certs/ca-certificates.crt:/run/test-ca.pem:ro','-e','SSL_CERT_FILE=/run/test-ca.pem','-e','REQUESTS_CA_BUNDLE=/run/test-ca.pem','-p','127.0.0.1:3000:3000','-p','127.0.0.1:8080:3000','-p','127.0.0.1:9090:3000',image]
def validate(body):
 assert all(e in body.get('answer','') for e in employers),body
 assert re.search(r'\b(?:5|five)\b',body['answer'],re.I),body
 citations=body['citations'];pages={c['page_number'] for c in citations}
 assert {1,2,4,5,6}<=pages<={1,2,3,4,5,6},body
 snapshot=json.loads(records());publication=snapshot['doclens_document_publications'][0]['payload']['revision']
 active=[p['payload'] for p in snapshot['document_chunks'] if p['payload'].get('_doclens_revision')==publication]
 for c in citations:assert any(all(p.get(k)==c[k] for k in ['document_name','page_number','chunk_id']) for p in active),c
 return sorted(pages)
def ask(question,cookie):
 status,_,body=request('/api/ask',json.dumps({'question':question,'document_name':'synthetic.pdf'}).encode(),cookie);assert status==200,(status,body)
 pages=validate(body)
 with (out/'live-answers.jsonl').open('a') as f:f.write(json.dumps({'question':question,'response':body,'validated_pages':pages})+'\n')
 print('PASS live count 5/all five employers, valid complete citations; pages='+str(pages),flush=True)
def warm(cookie):
 deadline=time.monotonic()+75
 for query in ['doclens_auth_login_success_total{job="doclens"}','up{job="qdrant"}']:
  while True:
   r=metric(query,cookie)
   if r and float(r[0]['value'][1])>=1:break
   assert time.monotonic()<deadline,'Required scrape sample unavailable';time.sleep(.5)
settings_code="from pathlib import Path;import hashlib,json;print(json.dumps({str(p.relative_to('/config')):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('/config').rglob('*') if p.is_file()},sort_keys=True))"
try:
 docker('volume','create',volume);docker(*args);wait()
 assert docker('inspect','--format','{{.Image}}',name)==image
 bindings=json.loads(docker('inspect','--format','{{json .HostConfig.PortBindings}}',name));assert set(bindings)=={'3000/tcp'} and {b['HostPort'] for b in bindings['3000/tcp']}=={'3000','8080','9090'} and all(b['HostIp']=='127.0.0.1' for b in bindings['3000/tcp'])
 (out/'mounts.json').write_text(docker('inspect','--format','{{json .Mounts}}',name)+'\n')
 print('PASS exact image/fixed local ports 3000,8080,9090; raw services not published',flush=True)
 status,headers,_=request('/api/auth/login',json.dumps({'email':'trial@synthetic.invalid','password':'Synthetic-$literal-Password-2026'}).encode());assert status==200;cookie=headers['Set-Cookie'].split(';',1)[0]
 assert upload(pdf(texts),cookie)[0]==200;warm(cookie)
 # The first wording already passed before the original harness failed.
 for q in ['List the number of organizations Taylor has worked in according to the attached CV','Count the employers in this CV']:ask(q,cookie)
 for address in ['http://127.0.0.1:8080/monitoring/api/dashboards/uid/doclens','http://127.0.0.1:9090/prometheus/api/v1/query?query=up']:
  opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
  try:opener.open(urllib.request.Request(address,headers={'X-DocLens-Grafana-User':'admin'}),timeout=20);raise AssertionError('Anonymous monitoring allowed')
  except urllib.error.HTTPError as e:assert e.code==401
  with opener.open(urllib.request.Request(address,headers={'Cookie':cookie}),timeout=20) as r:assert r.status==200
 print('PASS fixed-port monitoring authentication and anonymous/spoof denial',flush=True)
 fixture=out/'synthetic.pdf';fixture.write_bytes(pdf(texts))
 browser_env=dict(os.environ,DOCLENS_TEST_URL='http://127.0.0.1:3000',DOCLENS_SYNTHETIC_PDF=str(fixture),DOCLENS_BROWSER_OUTPUT=str(out/'real-browser'))
 subprocess.run(['node','/workspace/DocLens-d909540-acceptance/browser-real-flow.cjs'],env=browser_env,check=True)
 before=records();saved=docker('exec',name,'python','-c',settings_code)
 expected={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('/workspace/DocLens-d909540-acceptance/source/backend').iterdir() if p.is_file() and (p.suffix=='.py' or p.name=='requirements.txt')}
 actual=json.loads(docker('exec','-u','0',name,'python','-c',"from pathlib import Path;import hashlib,json;print(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('/app').iterdir() if p.is_file() and (p.suffix=='.py' or p.name=='requirements.txt')}))"));assert actual==expected
 (out/'backend-source-integrity.json').write_text(json.dumps(actual,indent=2)+'\n')
 history_time=time.time();history=metric('doclens_auth_login_success_total{job="doclens"}',cookie,history_time)
 assert monitor('api/user/preferences',cookie,json.dumps({'timezone':'utc','homeDashboardUID':'doclens'}).encode(),method='PUT')[0]==200
 docker('exec',name,'python','-c',"from pathlib import Path;p=Path('/run/doclens-initial.env');p.write_text('stale-synthetic-input');p.chmod(0o600)")
 docker('kill','--signal','KILL',name);docker('start',name);wait()
 assert records()==before and docker('exec',name,'python','-c',settings_code)==saved and upload(b'bad replacement',cookie)[0]==400
 print('PASS interrupted/forced restart: documents, saved settings and session preserved',flush=True)
 docker('restart','-t','30',name);wait();assert records()==before and upload(b'bad replacement',cookie)[0]==400
 assert metric('doclens_auth_login_success_total{job="doclens"}',cookie,history_time)==history
 assert monitor('api/user/preferences',cookie)[1]['timezone']=='utc'
 print('PASS graceful restart: document/citation identities, session and monitoring history/settings preserved',flush=True)
 (out/'before-recreate-container.log').write_text(docker('logs','--timestamps',name))
 docker('stop','-t','30',name);docker('rm',name);docker(*args);wait()
 assert records()==before and docker('exec',name,'python','-c',settings_code)==saved and upload(b'bad replacement',cookie)[0]==400
 assert metric('doclens_auth_login_success_total{job="doclens"}',cookie,history_time)==history and monitor('api/user/preferences',cookie)[1]['timezone']=='utc'
 print('PASS container removal/recreation with same synthetic volume preserves documents/session/history/config',flush=True)
 docker('exec',name,'python','-c',"import os,signal;from pathlib import Path;p=next(p for p in Path('/proc').iterdir() if p.name.isdigit() and p.stat().st_uid==10004 and b'/opt/grafana/bin/grafana' in (p/'cmdline').read_bytes());os.kill(int(p.name),signal.SIGTERM)")
 deadline=time.monotonic()+20
 while monitor('api/dashboards/uid/doclens',cookie)[0]!=502:
  assert time.monotonic()<deadline;time.sleep(.25)
 assert upload(b'bad replacement',cookie)[0]==400 and records()==before;ask('Count the employers in this CV',cookie)
 docker('restart','-t','30',name);wait();assert monitor('api/user/preferences',cookie)[1]['timezone']=='utc'
 print('PASS Grafana failure leaves app live and restart restores monitoring',flush=True)
 docker('exec',name,'python','-c',"import os,signal;from pathlib import Path;p=next(p for p in Path('/proc').iterdir() if p.name.isdigit() and p.stat().st_uid==10002 and b'/opt/qdrant/qdrant' in (p/'cmdline').read_bytes());os.kill(int(p.name),signal.SIGTERM)")
 deadline=time.monotonic()+40
 while docker('inspect','--format','{{.State.Running}}',name)=='true':
  assert time.monotonic()<deadline;time.sleep(.5)
 print('PASS core Qdrant failure shuts down entire single-container application',flush=True)
 (out/'result.json').write_text(json.dumps({'commit':'d9095402cf393aa75f790c8e13b15ee215575412','image_id':image,'continued_acceptance':'passed','ports':[3000,8080,9090],'citation_criteria':'Required employer pages 1,2,4,5,6; optional directly relevant exclusion page 3; reject education-only/nonexistent/wrong-revision citations','actual_runpod':'pending'},indent=2)+'\n')
finally:
 (out/'final-container.log').write_text(docker('logs','--timestamps',name,check=False))
 docker('rm','-f',name,check=False);docker('volume','rm',volume,check=False);private.cleanup()
