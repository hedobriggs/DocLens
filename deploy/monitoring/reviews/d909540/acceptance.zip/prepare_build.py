from pathlib import Path
import subprocess,json,hashlib,os
out=Path(__file__).parent;root=Path('/workspace/DocLens');commit='d9095402cf393aa75f790c8e13b15ee215575412'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==commit
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
assert subprocess.run(['docker','--host=unix:///var/run/docker.sock','info','--format','{{.Driver}}'],capture_output=True).returncode==0
old='sha256:50c0082e7ee05e1595d543d9ca3319d53e048296ee6289f182e0ff2ec0f5f5e9'
x=json.loads(subprocess.check_output(['docker','image','inspect',old]))[0]
assert x['RepoTags']==['doclens-mac-counts:review']
assert not subprocess.check_output(['docker','ps','-a','-q','--filter','ancestor='+old],text=True).strip()
with (out/'superseded-prototype-removal.log').open('w') as log:
 log.write('Only previous-task local pre-final-source prototype removed. Published monitoring image, backend dependencies and unrelated images/volumes retained.\n')
 r=subprocess.run(['docker','image','rm',old],stdout=log,stderr=subprocess.STDOUT);assert r.returncode==0
source=out/'source';source.mkdir()
with (out/'source.tar').open('wb') as f:subprocess.run(['git','archive',commit],cwd=root,stdout=f,check=True)
subprocess.run(['tar','-xf',str(out/'source.tar'),'-C',str(source)],check=True)
files=subprocess.check_output(['git','ls-tree','-r','--name-only',commit],cwd=root,text=True).splitlines()
checks={}
for n in files:
 f=source/n
 if f.is_file():
  assert f.read_bytes()==subprocess.check_output(['git','show',commit+':'+n],cwd=root)
  checks[n]=hashlib.sha256(f.read_bytes()).hexdigest()
(out/'source-file-sha256.json').write_text(json.dumps({'commit':commit,'files':checks},indent=2)+'\n')
print('PASS exact clean commit and extracted build context',flush=True)
