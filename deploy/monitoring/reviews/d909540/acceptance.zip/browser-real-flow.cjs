// Real form login/upload/ask and monitoring; no API stubs or cookie injection.
const {createRequire}=require('node:module'),path=require('node:path'),fs=require('node:fs');
const req=createRequire('/workspace/DocLens/frontend/package.json');
const {chromium}=req('playwright'),{expect}=req('@playwright/test');
(async()=>{
 const base=process.env.DOCLENS_TEST_URL.replace('127.0.0.1','localhost');
 const output=process.env.DOCLENS_BROWSER_OUTPUT;fs.mkdirSync(output,{recursive:true});
 const employers=['Aster Research','Birch Analytics','Cobalt Systems','Delta Robotics','Elm Computing'];
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
 const context=await browser.newContext({viewport:{width:1280,height:800}});const page=await context.newPage();
 try{
  await page.goto(base+'/');
  await page.getByLabel('Email',{exact:true}).fill('trial@synthetic.invalid');
  await page.getByLabel('Password',{exact:true}).fill('Synthetic-$literal-Password-2026');
  await page.getByRole('button',{name:'Sign in',exact:true}).click();
  await expect(page).toHaveURL(/\/dashboard$/,{timeout:15000});
  const cookie=(await context.cookies()).find(c=>c.name==='doclens_session');
  if(!cookie||!cookie.secure||!cookie.httpOnly)throw Error('Real form login cookie missing secure/HttpOnly flags');
  console.log('PASS real Chromium form login on HTTP localhost loopback; secure/HttpOnly cookie accepted without injection');
  await page.locator('input[type=file]').setInputFiles(process.env.DOCLENS_SYNTHETIC_PDF);
  await expect(page.getByRole('status')).toContainText('ready for questions',{timeout:120000});
  await page.getByRole('textbox',{name:'Question about the selected document'}).fill('How many organizations has Taylor worked in?');
  const answered=page.waitForResponse(r=>r.url().endsWith('/api/ask')&&r.request().method()==='POST',{timeout:120000});
  await page.getByRole('button',{name:'Send question'}).click();
  const response=await answered;if(response.status()!==200)throw Error('Real UI ask HTTP '+response.status());
  const data=await response.json();
  if(!employers.every(n=>data.answer.includes(n))||!(/\b(?:5|five)\b/i.test(data.answer)))throw Error('Incomplete UI answer');
  const pages=[...new Set(data.citations.map(c=>c.page_number))].sort();
  if(![1,2,4,5,6].every(p=>pages.includes(p))||pages.some(p=>![1,2,3,4,5,6].includes(p))||data.citations.some(c=>c.document_name!=='synthetic.pdf'||c.chunk_id!=='p'+c.page_number+'-c1'))throw Error('Invalid or incomplete UI citations');
  await expect(page.locator('.legal-answer').last()).toContainText('Elm Computing');
  await expect(page.locator('.legal-answer').last().locator('summary')).toHaveCount(pages.length);
  await page.screenshot({path:path.join(output,'real-ui-answer-citations.png'),fullPage:true});
  console.log('PASS real browser PDF upload, live Gemini total 5/all five employers, all employer citation controls/pages (optional client-exclusion evidence allowed)');
  const charts=await context.newPage();
  const query=charts.waitForResponse(r=>r.url().includes('/monitoring/api/ds/query')&&r.request().method()==='POST',{timeout:60000});
  await charts.goto('http://localhost:8080/monitoring/d/doclens');
  await expect(charts.locator('body')).toContainText('DocLens Operations',{timeout:60000});
  if((await query).status()!==200)throw Error('Grafana dashboard query failed');
  await expect(charts.getByText('qdrant',{exact:true}).first()).toBeVisible({timeout:60000});
  await charts.screenshot({path:path.join(output,'real-session-grafana.png'),fullPage:true});
  const prom=await context.newPage();await prom.goto('http://localhost:9090/prometheus/query');
  await expect(prom.locator('body')).toContainText('Execute',{timeout:30000});
  const result=await prom.evaluate(async()=>{const r=await fetch('/prometheus/api/v1/query?query=up');return {status:r.status,body:await r.json()}});
  if(result.status!==200||result.body.status!=='success'||result.body.data.result.length<2||result.body.data.result.some(r=>r.value[1]!=='1'))throw Error('Real browser Prometheus targets not up');
  await prom.screenshot({path:path.join(output,'real-session-prometheus.png'),fullPage:true});
  const summary={real_form_login:true,cookie_secure:true,cookie_http_only:true,real_upload:true,live_gemini_count:5,employers,citation_pages:pages,grafana_separate_port:8080,grafana_real_queries:true,prometheus_separate_port:9090,prometheus_live_up_targets:result.body.data.result.length,transport:'HTTP localhost Chromium loopback exception; NOT HTTPS/RunPod',api_stubs:false,cookie_injection:false};
  fs.writeFileSync(path.join(output,'result.json'),JSON.stringify(summary,null,2)+'\n');
  console.log('PASS real signed-in session shared across separate Grafana/Prometheus ports, real dashboard queries and live target data');
 }catch(e){await page.screenshot({path:path.join(output,'failure.png'),fullPage:true}).catch(()=>{});throw e}
 finally{await context.close();await browser.close()}
})().catch(e=>{console.error(e.stack);process.exit(1)});
