"""Complete unmodified Compose monitoring stack, fresh synthetic volumes only."""
from pathlib import Path
import os,subprocess,tempfile,json,time,urllib.request,urllib.error,uuid,hashlib
root=Path('/workspace/DocLens');out=Path(__file__).parent
namespace={'__file__':str(root/'tests/test_runpod.py')}
exec(compile((root/'tests/test_runpod.py').read_text().split('\ntry:\n')[0],str(root/'tests/test_runpod.py'),'exec'),namespace)
project='doclens-monitoring-acceptance-'+uuid.uuid4().hex[:8]
env=dict(os.environ,COMPOSE_PROJECT_NAME=project,FRONTEND_IMAGE='doclens-d909540-frontend:acceptance',BACKEND_IMAGE='doclens-d909540-backend:acceptance',HTTP_PORT='3000',BIND_ADDRESS='127.0.0.1',COMPOSE_PARALLEL_LIMIT='1')
private=tempfile.TemporaryDirectory(prefix='doclens-compose-synthetic-');checkout=Path(private.name)/'source';checkout.mkdir()
archive=subprocess.Popen(['git','-C',str(root),'archive','d9095402cf393aa75f790c8e13b15ee215575412'],stdout=subprocess.PIPE)
subprocess.run(['tar','-x','-C',str(checkout)],stdin=archive.stdout,check=True);archive.stdout.close();assert archive.wait()==0
# Public configuration mounts must be readable by container UIDs under umask 077.
for p in checkout.rglob('*'):
 if p.is_dir():p.chmod(0o755)
 elif p.is_file():p.chmod(0o644)
checkout.chmod(0o755);Path(private.name).chmod(0o755)
secret=checkout/'.env';secret.write_text("GEMINI_API_KEY="+os.environ['GEMINI_API_KEY']+"\nDOCLENS_ADMIN_EMAIL=trial@synthetic.invalid\nDOCLENS_ADMIN_PASSWORD='Synthetic-$literal-Password-2026'\n");secret.chmod(0o600)
base=['docker','compose','--env-file','/dev/null','-p',project,'-f',str(checkout/'compose.yaml'),'-f',str(checkout/'compose.monitoring.yaml'),'-f',str(checkout/'compose.monitoring.local.yaml'),'-f',str(out/'compose-test-environment.yaml')]
log=(out/'compose-commands-complete.log').open('w')
def command(args,check=True):
 log.write('$ '+' '.join(args)+'\n');log.flush();r=subprocess.run(args,text=True,capture_output=True,env=env);log.write(r.stdout+r.stderr+'\nEXIT '+str(r.returncode)+'\n');log.flush()
 if check and r.returncode:raise AssertionError('Command failed: '+' '.join(args[:5])+' (see complete log)')
 return r.stdout.strip()
def compose(*args,**kwargs):return command(base+list(args),**kwargs)
def container(service):return compose('ps','-a','-q',service)
def wait_healthy(service):
 deadline=time.monotonic()+180
 while time.monotonic()<deadline:
  state=json.loads(command(['docker','inspect','--format','{{json .State}}',container(service)]))
  if state.get('Health',{}).get('Status')=='healthy':return
  time.sleep(.5)
 raise AssertionError(service+' health timeout')
original=namespace['docker'];ids={}
def adapted(*args,check=True):
 if args[0]=='port':args=('port',ids['frontend'],args[2])
 elif args[0]=='exec':args=('exec',ids['backend'],*[(a.replace('http://127.0.0.1:6333','http://qdrant:6333') if isinstance(a,str) else a) for a in args[2:]])
 return command(['docker',*args],check=check)
namespace['docker']=adapted
request=namespace['request'];upload=namespace['upload'];records=namespace['records'];metric=namespace['metric'];monitor=namespace['monitor'];pdf=namespace['pdf'];employers=namespace['EMPLOYERS']
def ask(cookie):
 import re
 for question in ['how many organizations has Taylor worked in?', 'List the number of organizations Taylor has worked in according to the attached CV', 'Count the employers in this CV']:
  status,_,body=request('/api/ask',json.dumps({'question':question,'document_name':'synthetic.pdf'}).encode(),cookie)
  assert status==200 and all(e in body.get('answer','') for e in employers),(status,body)
  assert re.search(r'\b(?:5|five)\b',body['answer'],re.I),body
  pages={c['page_number'] for c in body.get('citations',[])}
  assert {1,2,4,5,6}<=pages<={1,2,3,4,5,6},body
  snapshot=json.loads(records());revision=snapshot['doclens_document_publications'][0]['payload']['revision']
  active=[p['payload'] for p in snapshot['document_chunks'] if p['payload'].get('_doclens_revision')==revision]
  for citation in body['citations']:assert any(all(row.get(k)==citation[k] for k in ['document_name','page_number','chunk_id']) for row in active),citation
  with (out/'live-answers.jsonl').open('a') as evidence: evidence.write(json.dumps({'question':question,'response':body})+'\n')
  print('PASS live Gemini total 5, all five employers and correct citation pages: '+question,flush=True)

try:
 config=json.loads(compose('config','--format','json'))
 for name,s in config['services'].items():
  if name!='frontend':assert not s.get('ports'),name+' has public ports'
 assert {str(p['published']) for p in config['services']['frontend']['ports']}=={'3000','8080','9090'}
 assert all(p['host_ip']=='127.0.0.1' and p['target']==3000 for p in config['services']['frontend']['ports'])
 compose('up','-d','--no-build','--pull','never','--wait','--wait-timeout','240')
 ids={s:container(s) for s in ['frontend','backend','qdrant','prometheus','grafana']}
 expected_ids={'frontend':'sha256:60f8893a7727fa08a6457ad4b255b9d47a2da103270484651dd69e70611ac30e','backend':'sha256:6630a9b44c22c047906d1aaba571f39e4e72d075921297dbc480ea98d01140b5'}
 for service,expected_id in expected_ids.items():assert command(['docker','inspect','--format','{{.Image}}',ids[service]])==expected_id
 for service in ['frontend','backend','prometheus','grafana']:wait_healthy(service)
 assert command(['docker','inspect','--format','{{.State.Status}}',ids['qdrant']])=='running'
 for s,c in ids.items():
  bindings=json.loads(command(['docker','inspect','--format','{{json .HostConfig.PortBindings}}',c]) or '{}')
  if s!='frontend':assert not bindings
  else:assert all(x['HostIp']=='127.0.0.1' for b in bindings.values() for x in b)
 print('PASS full Compose fresh startup, healthy services and frontend-only loopback publication',flush=True)
 assert upload(pdf(['Anonymous']))[0]==401
 assert monitor('api/dashboards/uid/doclens',spoof=True)[0]==401
 assert request('/api/auth/login',json.dumps({'email':'trial@synthetic.invalid','password':'wrong'}).encode())[0]==401
 status,headers,_=request('/api/auth/login',json.dumps({'email':'trial@synthetic.invalid','password':'Synthetic-$literal-Password-2026'}).encode());assert status==200
 assert 'Secure' in headers['Set-Cookie'] and 'HttpOnly' in headers['Set-Cookie'];cookie=headers['Set-Cookie'].split(';',1)[0]
 assert monitor('api/dashboards/uid/doclens',cookie)[1]['dashboard']['title']=='DocLens Operations'
 assert monitor('api/user',cookie,spoof='untrusted-client')[1]['login']=='admin'
 status,_,body=upload(pdf(['Employer: '+employers[0],'Employer: '+employers[1],'Client: Nimbus Partners. Vendor: Orion tools. Neither is an employer.',*['Employer: '+e for e in employers[2:]],'Education: Synthetic University.']),cookie);assert status==200 and body['indexed'] and body['total_chunks']==7,(status,body)
 before=records()
 for bad,expected in [(b'not PDF',400),(pdf(['Page']*301),413)]:
  assert upload(bad,cookie)[0]==expected;assert records()==before
 ask(cookie)
 for address in ['http://127.0.0.1:8080/monitoring/api/dashboards/uid/doclens','http://127.0.0.1:9090/prometheus/api/v1/query?query=up']:
  opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
  try:opener.open(urllib.request.Request(address,headers={'X-DocLens-Grafana-User':'admin'}),timeout=20);raise AssertionError('Anonymous local monitor API allowed')
  except urllib.error.HTTPError as exc:assert exc.code==401
  with opener.open(urllib.request.Request(address,headers={'Cookie':cookie}),timeout=20) as response:assert response.status==200
 print('PASS separate Grafana/Prometheus ports authenticated; anonymous/spoofed access rejected',flush=True)
 print('PASS authenticated Grafana, anonymous/spoof denial, real-model PDF and failed-replacement preservation',flush=True)
 deadline=time.monotonic()+75
 while not metric('doclens_auth_login_success_total{job="doclens"}',cookie):
  assert time.monotonic()<deadline;time.sleep(.5)
 for job in ['qdrant','doclens']:
  deadline=time.monotonic()+60
  while True:
   up=metric('up{job="'+job+'"}',cookie)
   if up and float(up[0]['value'][1])==1:break
   assert time.monotonic()<deadline,job+' target never healthy'
   time.sleep(.5)
 for panel in json.loads((root/'deploy/monitoring/dashboards/doclens.json').read_text())['panels']:metric(panel['targets'][0]['expr'].replace('$__rate_interval','1m'),cookie)
 assert monitor('api/user/preferences',cookie,json.dumps({'timezone':'utc','homeDashboardUID':'doclens'}).encode(),method='PUT')[0]==200
 print('PASS real Prometheus app/Qdrant samples, all 12 panel queries and persistent Grafana preferences',flush=True)
 fixture_path=out/'synthetic.pdf';fixture_path.write_bytes(pdf(['Employer: '+employers[0],'Employer: '+employers[1],'Client: Nimbus Partners. Vendor: Orion tools. Neither is an employer.',*['Employer: '+e for e in employers[2:]],'Education: Synthetic University.']))
 real_env=dict(env,DOCLENS_TEST_URL='http://127.0.0.1:3000',DOCLENS_SYNTHETIC_PDF=str(fixture_path),DOCLENS_BROWSER_OUTPUT=str(out/'real-browser'))
 subprocess.run(['node','/workspace/DocLens-d909540-acceptance/browser-real-flow.cjs'],env=real_env,check=True)
 before=records()
 # Verify the actual backend, not only the host checkout or image tag.
 expected={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in Path('/workspace/DocLens-d909540-acceptance/source/backend').iterdir() if f.is_file() and (f.suffix=='.py' or f.name=='requirements.txt')}
 code="from pathlib import Path;import hashlib,json;print(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('/app').iterdir() if p.is_file() and (p.suffix=='.py' or p.name=='requirements.txt')}))"
 actual=json.loads(command(['docker','exec','-u','0',ids['backend'],'python','-c',code]));assert actual==expected
 (out/'backend-source-integrity.json').write_text(json.dumps(actual,indent=2)+'\n')
 print('PASS backend source/requirements match exact approved commit',flush=True)
 history_time=time.time();history=metric('doclens_auth_login_success_total{job="doclens"}',cookie,history_time)
 saved=command(['docker','exec','-u','0',ids['backend'],'python','-c',"from pathlib import Path;import json,hashlib;print(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('/config').rglob('*') if p.is_file()},sort_keys=True))"])
 old_ids=dict(ids)
 compose('down','--timeout','30');compose('up','-d','--no-build','--pull','never','--wait','--wait-timeout','240')
 ids.update({service:container(service) for service in ids})
 assert all(old_ids[service]!=ids[service] for service in ids), 'Down/up did not recreate services'
 assert records()==before and upload(b'bad replacement',cookie)[0]==400
 assert metric('doclens_auth_login_success_total{job="doclens"}',cookie,history_time)==history
 assert monitor('api/user/preferences',cookie)[1]['timezone']=='utc'
 assert command(['docker','exec','-u','0',ids['backend'],'python','-c',"from pathlib import Path;import json,hashlib;print(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('/config').rglob('*') if p.is_file()},sort_keys=True))"])==saved
 ask(cookie)
 print('PASS full-stack down/up with recreated containers preserves exact documents/citations, configuration, session, monitoring history and settings',flush=True)
 command(['docker','restart','-t','0',ids['prometheus']]);wait_healthy('prometheus')
 assert metric('doclens_auth_login_success_total{job="doclens"}',cookie,history_time)==history
 print('PASS forced Prometheus restart preserves historical samples',flush=True)
 compose('stop','-t','15','grafana')
 assert monitor('api/dashboards/uid/doclens',cookie)[0]==502
 assert upload(b'bad replacement',cookie)[0]==400 and records()==before
 ask(cookie)
 compose('start','grafana');wait_healthy('grafana')
 assert monitor('api/user/preferences',cookie)[1]['timezone']=='utc'
 print('PASS monitoring failure leaves DocLens question answering and API usable; monitoring recovers',flush=True)
 compose('stop','-t','15','prometheus')
 assert upload(b'bad replacement',cookie)[0]==400 and records()==before
 ask(cookie)
 compose('start','prometheus');wait_healthy('prometheus')
 assert metric('doclens_auth_login_success_total{job="doclens"}',cookie,history_time)==history
 print('PASS stopped Prometheus leaves API/live answers available and restart preserves history',flush=True)
 restart_before=int(command(['docker','inspect','--format','{{.RestartCount}}',ids['backend']]))
 code="import os,signal;from pathlib import Path;p=next(p for p in Path('/proc').iterdir() if p.name.isdigit() and b'\\x00uvicorn\\x00' in (p/'cmdline').read_bytes());os.kill(int(p.name),signal.SIGKILL)"
 command(['docker','exec',ids['backend'],'python','-c',code])
 deadline=time.monotonic()+90
 while int(command(['docker','inspect','--format','{{.RestartCount}}',ids['backend']]))<=restart_before:
  assert time.monotonic()<deadline;time.sleep(.5)
 wait_healthy('backend');assert upload(b'bad replacement',cookie)[0]==400 and records()==before
 print('PASS Compose core API crash follows restart policy and preserves documents/session',flush=True)
 summary={'commit':'d9095402cf393aa75f790c8e13b15ee215575412','project':project,'before_down_container_ids':old_ids,'after_down_up_container_ids':dict(ids),'services':{s:{'image_id':command(['docker','inspect','--format','{{.Image}}',c]),'restart_count':command(['docker','inspect','--format','{{.RestartCount}}',c])} for s,c in ids.items()},'actual_runpod':'pending','native_mac_safari_voiceover':'not tested','https_browser_login':'not tested; real form browser login on HTTP localhost Chromium exception, no cookie injection'}
 (out/'compose-result.json').write_text(json.dumps(summary,indent=2)+'\n')
 print('PASS complete Compose monitoring acceptance',flush=True)
finally:
 compose('logs','--no-color','--timestamps',check=False)
 # These are only this random project's fresh synthetic volumes, never unrelated data.
 compose('down','--volumes','--remove-orphans',check=False)
 log.close();private.cleanup()
